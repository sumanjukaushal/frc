<?php
	require_once("../../wp-config.php");
	$link = mysql_connect('localhost', DB_USER, DB_PASSWORD);
	mysql_select_db(DB_NAME, $link) or die('Could not select database.');
	/*
	require_once('../../wp-load.php');
	require_once('../../wp-blog-header.php');
	$current_user = wp_get_current_user();
	echo "<pre>====";print_r($current_user);
	print_r($_SESSION);
        print_r($_GET);
        print_r($_COOKIE);
	echo "user_id:".$user_ID = get_current_user_id();
	*/
	if(isset($_REQUEST['save_preference'])){
		$category = "";
		if(isset($_REQUEST['category']) && !empty($_REQUEST['category'])){
			$category = implode(",", $_REQUEST['category']);
		}
		
		$locRadius = "";
		if(isset($_REQUEST['loc_radius']) && !empty($_REQUEST['loc_radius'])){
			$locRadius = (int)$_REQUEST['loc_radius'];
		}
		
		$location = "";
		if(isset($_REQUEST['location']) && !empty($_REQUEST['location'])){
			$location = implode(",", $_REQUEST['location']);
		}
		
		$feature = "";
		if(isset($_REQUEST['feature']) && !empty($_REQUEST['feature'])){
			$feature = implode(",", $_REQUEST['feature']);
		}
		$id = 0;
		if(isset($_REQUEST['id'])){
			$id = (int)$_REQUEST['id'];
		}
		$customLocation = "";
		if(!empty($_REQUEST['search'])){$customLocation = trim($_REQUEST['search']);}
		$query = "INSERT INTO `saved_preferences` SET `user_id` = $id, `locations` = '$location', `custom_location` = '$customLocation', `radius` = '$locRadius', `categories` = '$category', `features` = '$feature'";
		mysql_query($query) or  die('Invalid query: ' . mysql_error());
		die();
	}
?>