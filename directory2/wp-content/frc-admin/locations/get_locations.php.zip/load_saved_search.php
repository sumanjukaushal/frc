<?php
	require_once("../../wp-config.php");
	header('Content-Type: application/json');
	$link = mysql_connect('localhost', DB_USER, DB_PASSWORD);
	mysql_select_db(DB_NAME, $link) or die('Could not select database.');
	if(isset($_REQUEST['load_preference'])){
		$userID = (int)$_REQUEST['id'];
		$query = "SELECT `features`, `categories` FROM `saved_preferences` WHERE `user_id` = $userID ORDER BY `id` DESC LIMIT 1";
		$query = "SELECT * FROM `saved_preferences` WHERE `user_id` = $userID ORDER BY `id` DESC LIMIT 1";
		$rs = mysql_query($query) or  die('Invalid query: ' . mysql_error());
		if(mysql_num_rows($rs) >= 1){
			$rowObj = mysql_fetch_assoc($rs);
			/*$catArr = explode(",",$rowObj['categories']);
			$catStr = "";
			if(is_array($catArr)){
				$catStr = "'".implode("','",$catArr)."'";
			}
			$rowObj['categories'] = $catStr;*/
			//unset($rowObj['locations']);
			//unset($rowObj['custom_location']);
			echo json_encode($rowObj);
		}else{
			echo json_encode(array());
		}
	}
	die;
?>